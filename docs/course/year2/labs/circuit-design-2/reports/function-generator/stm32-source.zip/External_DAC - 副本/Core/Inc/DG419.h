#ifndef __DG419_H__
#define __DG419_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f1xx_hal.h"
#include <stdint.h>

/*
 * DG419��ֵ���ֲᣩ��
 * IN = 0 -> S1 ON, S2 OFF
 * IN = 1 -> S1 OFF, S2 ON
 */
typedef enum
{
    DG419_PATH_S1 = 0,  /* ����֧·��ͨ */
    DG419_PATH_S2 = 1   /* ����֧·��ͨ */
} DG419_Path_t;

typedef struct
{
    GPIO_TypeDef *inPort;
    uint16_t      inPin;
} DG419_HandleTypeDef;

HAL_StatusTypeDef DG419_Init(DG419_HandleTypeDef *dev, DG419_Path_t defaultPath);
void DG419_SetPath(DG419_HandleTypeDef *dev, DG419_Path_t path);
void DG419_Toggle(DG419_HandleTypeDef *dev);

#ifdef __cplusplus
}
#endif

#endif /* __DG419_H__ */
