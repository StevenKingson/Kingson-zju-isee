#include "mcp42100.h"

/*
 * MCP42XXX �����ֽڸ�ʽ���ֲᣩ��
 * [7:6]=X, [5:4]=C1:C0, [3:2]=X, [1:0]=P1:P0
 * C1:C0 = 01 -> Write Data
 * C1:C0 = 10 -> Shutdown
 */
#define MCP42100_CMD_WRITE      (0x10U)  /* C1:C0 = 01 */
#define MCP42100_CMD_SHUTDOWN   (0x20U)  /* C1:C0 = 10 */

#define MCP42100_SEL_P0         (0x01U)  /* P0 */
#define MCP42100_SEL_P1         (0x02U)  /* P1 */
#define MCP42100_SEL_BOTH       (0x03U)  /* P1|P0 */

static inline void MCP42100_CS_Low(MCP42100_HandleTypeDef *dev)
{
    HAL_GPIO_WritePin(dev->csPort, dev->csPin, GPIO_PIN_RESET);
}

static inline void MCP42100_CS_High(MCP42100_HandleTypeDef *dev)
{
    HAL_GPIO_WritePin(dev->csPort, dev->csPin, GPIO_PIN_SET);
}

static HAL_StatusTypeDef MCP42100_SendFrame(MCP42100_HandleTypeDef *dev,
                                             uint8_t cmd,
                                             uint8_t data)
{
    uint8_t tx[2] = {cmd, data};

    MCP42100_CS_Low(dev);
    HAL_StatusTypeDef st = HAL_SPI_Transmit(dev->hspi, tx, 2, dev->timeout);
    MCP42100_CS_High(dev);

    return st;
}

HAL_StatusTypeDef MCP42100_Init(MCP42100_HandleTypeDef *dev)
{
    if (dev == NULL || dev->hspi == NULL || dev->csPort == NULL)
        return HAL_ERROR;

    if (dev->timeout == 0U)
        dev->timeout = 10U;

    /* Ĭ������CS */
    MCP42100_CS_High(dev);

    return HAL_OK;
}

HAL_StatusTypeDef MCP42100_SetWiper(MCP42100_HandleTypeDef *dev,
                                    MCP42100_Channel_t ch,
                                    uint8_t value)
{
    if (dev == NULL) return HAL_ERROR;

    uint8_t cmd = MCP42100_CMD_WRITE;
    cmd |= (ch == MCP42100_CH0) ? MCP42100_SEL_P0 : MCP42100_SEL_P1;

    return MCP42100_SendFrame(dev, cmd, value);
}

HAL_StatusTypeDef MCP42100_SetBoth(MCP42100_HandleTypeDef *dev,
                                   uint8_t value_ch0,
                                   uint8_t value_ch1)
{
    HAL_StatusTypeDef st;

    st = MCP42100_SetWiper(dev, MCP42100_CH0, value_ch0);
    if (st != HAL_OK) return st;

    st = MCP42100_SetWiper(dev, MCP42100_CH1, value_ch1);
    return st;
}

HAL_StatusTypeDef MCP42100_Shutdown(MCP42100_HandleTypeDef *dev,
                                    MCP42100_Channel_t ch)
{
    if (dev == NULL) return HAL_ERROR;

    uint8_t cmd = MCP42100_CMD_SHUTDOWN;
    cmd |= (ch == MCP42100_CH0) ? MCP42100_SEL_P0 : MCP42100_SEL_P1;

    /* data�ֽ� don't care */
    return MCP42100_SendFrame(dev, cmd, 0x00U);
}

HAL_StatusTypeDef MCP42100_ShutdownBoth(MCP42100_HandleTypeDef *dev)
{
    if (dev == NULL) return HAL_ERROR;

    return MCP42100_SendFrame(dev, MCP42100_CMD_SHUTDOWN | MCP42100_SEL_BOTH, 0x00U);
}

HAL_StatusTypeDef MCP42100_ReleaseFromShutdown(MCP42100_HandleTypeDef *dev,
                                                MCP42100_Channel_t ch,
                                                uint8_t newValue)
{
    /* �ֲ���Ϊ��д����ֵ���˳�����shutdown��Ӳ��SHDN��Ϊ��ʱ�� */
    return MCP42100_SetWiper(dev, ch, newValue);
}
