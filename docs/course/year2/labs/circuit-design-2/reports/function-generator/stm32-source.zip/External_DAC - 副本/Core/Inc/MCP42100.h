#ifndef __MCP42100_H__
#define __MCP42100_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f1xx_hal.h"
#include <stdint.h>

/* MCP42100 ͨ�� */
typedef enum
{
    MCP42100_CH0 = 0,   /* P0 */
    MCP42100_CH1 = 1    /* P1 */
} MCP42100_Channel_t;

/* MCP42100 �豸�����SPI + CS�ţ����������ã� */
typedef struct
{
    SPI_HandleTypeDef *hspi;  /* ���� &hspi2 */
    GPIO_TypeDef      *csPort;
    uint16_t           csPin;
    uint32_t           timeout; /* HAL SPI��ʱ����λms */
} MCP42100_HandleTypeDef;

/* API */
HAL_StatusTypeDef MCP42100_Init(MCP42100_HandleTypeDef *dev);

HAL_StatusTypeDef MCP42100_SetWiper(MCP42100_HandleTypeDef *dev,
                                    MCP42100_Channel_t ch,
                                    uint8_t value);

HAL_StatusTypeDef MCP42100_SetBoth(MCP42100_HandleTypeDef *dev,
                                   uint8_t value_ch0,
                                   uint8_t value_ch1);

HAL_StatusTypeDef MCP42100_Shutdown(MCP42100_HandleTypeDef *dev,
                                    MCP42100_Channel_t ch);

HAL_StatusTypeDef MCP42100_ShutdownBoth(MCP42100_HandleTypeDef *dev);

HAL_StatusTypeDef MCP42100_ReleaseFromShutdown(MCP42100_HandleTypeDef *dev,
                                                MCP42100_Channel_t ch,
                                                uint8_t newValue);

#ifdef __cplusplus
}
#endif

#endif /* __MCP42100_H__ */
