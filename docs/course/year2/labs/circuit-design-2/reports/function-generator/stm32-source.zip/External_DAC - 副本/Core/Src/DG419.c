#include "dg419.h"

HAL_StatusTypeDef DG419_Init(DG419_HandleTypeDef *dev, DG419_Path_t defaultPath)
{
    if (dev == NULL || dev->inPort == NULL) return HAL_ERROR;

    HAL_GPIO_WritePin(dev->inPort, dev->inPin,
                      (defaultPath == DG419_PATH_S2) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    return HAL_OK;
}

void DG419_SetPath(DG419_HandleTypeDef *dev, DG419_Path_t path)
{
    if (dev == NULL) return;

    HAL_GPIO_WritePin(dev->inPort, dev->inPin,
                      (path == DG419_PATH_S2) ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

void DG419_Toggle(DG419_HandleTypeDef *dev)
{
    if (dev == NULL) return;

    GPIO_PinState s = HAL_GPIO_ReadPin(dev->inPort, dev->inPin);
    HAL_GPIO_WritePin(dev->inPort, dev->inPin,
                      (s == GPIO_PIN_SET) ? GPIO_PIN_RESET : GPIO_PIN_SET);
}
